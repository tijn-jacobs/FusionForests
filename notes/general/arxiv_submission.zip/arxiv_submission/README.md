# arXiv submission package

A self-contained copy of the arXiv version: main article and Supplementary
Materials in one document. Nothing here is edited by hand — it is a copy of
the working files in `notes/`, with the `\input` paths flattened.

## Contents

| File | Source |
|---|---|
| `arxiv.tex` | `general/arxiv.tex`, `\input` paths flattened |
| `INTRODUCTION.tex` | `introduction/INTRODUCTION.tex` |
| `METHODOLOGY.tex` | `methodology/METHODOLOGY.tex` |
| `SIMULATION.tex` | `simulation/SIMULATION.tex` |
| `ANALYSIS.tex` | `data_analysis/ANALYSIS.tex` |
| `DISCUSSION.tex` | `general/DISCUSSION.tex` |
| `METHODOLOGY_SM.tex` | `methodology/METHODOLOGY_SM.tex` |
| `SIMULATION_SM.tex` | `simulation/SIMULATION_SM.tex` |
| `ANALYSIS_SM.tex` | `data_analysis/ANALYSIS_SM.tex` |
| `arxiv.bbl` | the compiled bibliography |
| `references.bib` | kept for convenience; arXiv does not use it |
| `figures/` | the 23 figures actually included |

## Why the .bbl matters

arXiv does not run BibTeX. It typesets the bibliography from `arxiv.bbl`
alone. If a citation is added, changed, or removed, recompile locally and
copy the regenerated `arxiv.bbl` here, or the reference list will be stale.

## Verified

Compiled from a clean copy of this directory with three `pdflatex` passes:
40 pages, no undefined references, no undefined citations, no overfull boxes
beyond 20pt. No build artefacts are kept here — upload the directory as is.

## Uploading

Tar the contents, not the directory itself:

    cd arxiv_submission && tar czf ../arxiv.tar.gz *

`arxiv.tex` is the only file with `\documentclass`, so arXiv will pick it as
the top-level source.
